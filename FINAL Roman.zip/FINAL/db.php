<?php
$DB_HOST = 'localhost';
$DB_USER = 'lev';
$DB_PASS = 'southhills#';
$DB_NAME = 'lev';
$mysqli = new mysqli($DB_HOST, $DB_USER, $DB_PASS, $DB_NAME);
?>
